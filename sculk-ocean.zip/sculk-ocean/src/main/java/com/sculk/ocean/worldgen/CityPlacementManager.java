package com.sculk.ocean.worldgen;

import com.sculk.ocean.config.SculkOceanConfig;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.world.ServerWorld;
import org.slf4j.Logger;

import java.util.List;

/**
 * Runs bounded, opt-in startup diagnostics for Ancient City placement.
 *
 * <p>This deliberately does <b>not</b> hook per-chunk or per-tick events: the real placement
 * work is done entirely by the engine's own structure-placement system (safe, deterministic,
 * and already tested by vanilla village/ancient-city generation), so there is nothing for this
 * mod to safely or usefully do on every chunk load. Doing so would also risk exactly the
 * "expensive operations during normal player movement" and "unbounded collections" problems the
 * design spec explicitly warns against. Instead, when {@code debugLogging} is enabled, this
 * logs one bounded (at most 81-entry) snapshot of predicted nearby city cells at server start.
 */
public final class CityPlacementManager {

	private CityPlacementManager() {
	}

	public static void onServerStarted(MinecraftServer server, SculkOceanConfig config, Logger logger) {
		if (!config.generateAncientCities) {
			logger.info("[Sculk Ocean] generateAncientCities is disabled in config - skipping placement diagnostics.");
			return;
		}
		if (!config.debugLogging) {
			return;
		}

		ServerWorld overworld = server.getOverworld();
		if (overworld == null) {
			logger.warn("[Sculk Ocean] No overworld present - skipping placement diagnostics.");
			return;
		}

		long seed = overworld.getSeed();
		logger.info("[Sculk Ocean] Ancient City placement diagnostics for seed {} "
						+ "(target spacing ~{} blocks, min separation ~{} blocks):",
				seed,
				AncientCityPlacement.SPACING_CHUNKS * 16,
				AncientCityPlacement.SEPARATION_CHUNKS * 16);

		if (!AncientCityPlacement.verifyDeterminism(seed)) {
			// Should be unreachable - predictCellCenter is a pure function - but if this ever
			// fails it means the diagnostics math was changed to depend on mutable state, which
			// would make the logged candidates misleading. Fail loudly rather than silently.
			logger.error("[Sculk Ocean] Determinism self-check FAILED - placement diagnostics below may be unreliable.");
		}

		List<AncientCityPlacement.CityCandidate> candidates =
				AncientCityPlacement.nearestCandidates(seed, 0, 0, 2);

		for (AncientCityPlacement.CityCandidate candidate : candidates) {
			logger.info("[Sculk Ocean]   cell ({}, {}) -> approx. block ({}, ~{}, {})",
					candidate.cellX(), candidate.cellZ(),
					candidate.approxBlockX(), config.surfaceHeight, candidate.approxBlockZ());
		}

		logger.info("[Sculk Ocean] Note: these are predicted candidate positions for diagnostics "
				+ "only, computed independently of the engine's own placement RNG. Use "
				+ "'/locate structure sculk_ocean:sculk_ancient_city' in-game to find the "
				+ "actual, authoritative locations.");
	}
}
