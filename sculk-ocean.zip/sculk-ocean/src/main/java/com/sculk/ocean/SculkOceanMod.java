package com.sculk.ocean;

import com.sculk.ocean.config.SculkOceanConfig;
import com.sculk.ocean.worldgen.CityPlacementManager;
import com.sculk.ocean.worldgen.SculkTerrainGenerator;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Entrypoint for Sculk Ocean: Ancient City World.
 *
 * <p>All of the actual world generation (terrain shape, surface blocks, biome, structure
 * placement, and the "no normal structures" behaviour) is implemented as data
 * ({@code src/main/resources/data/...}), selectable in the vanilla "World Type" button on the
 * Create World screen - no command is required to use this mod. See the README for details and
 * for an explanation of exactly why that architecture was chosen over a hand-written
 * {@code ChunkGenerator}.
 *
 * <p>This class's Java-side job is limited to: loading and validating
 * {@code config/sculk_ocean.json}, and running bounded, opt-in startup diagnostics.
 */
public final class SculkOceanMod implements ModInitializer {

	public static final String MOD_ID = "sculk_ocean";
	public static final Logger LOGGER = LoggerFactory.getLogger("Sculk Ocean");

	private static volatile SculkOceanConfig config = new SculkOceanConfig();

	@Override
	public void onInitialize() {
		LOGGER.info("[Sculk Ocean] Initializing Sculk Ocean: Ancient City World...");

		config = SculkOceanConfig.load(LOGGER);
		LOGGER.info("[Sculk Ocean] Loaded config: {}", config);

		SculkTerrainGenerator.logArchitectureSummary(config, LOGGER);

		ServerLifecycleEvents.SERVER_STARTED.register(server ->
				CityPlacementManager.onServerStarted(server, config, LOGGER));

		LOGGER.info("[Sculk Ocean] Initialization complete. Select 'Sculk Ocean: Ancient City "
				+ "World' as the World Type when creating a new world.");
	}

	/** The currently loaded config. Populated during {@link #onInitialize()}. */
	public static SculkOceanConfig getConfig() {
		return config;
	}
}
