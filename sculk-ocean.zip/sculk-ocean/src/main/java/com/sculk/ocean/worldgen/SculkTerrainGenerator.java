package com.sculk.ocean.worldgen;

import com.sculk.ocean.config.SculkOceanConfig;
import org.slf4j.Logger;

/**
 * Describes and sanity-checks the terrain generation architecture actually used by Sculk Ocean.
 *
 * <h2>Architecture decision (read this before "fixing" the lack of a ChunkGenerator subclass)</h2>
 * Sculk Ocean does <b>not</b> implement a custom {@code ChunkGenerator} or density-function
 * graph from scratch in Java. That was deliberately rejected as unreliable: hand-written
 * terrain shaping code is exactly the kind of "unsafe hack" the design spec warns against, and
 * Minecraft 1.21.1's noise-based terrain system is already fully data-driven.
 * <p>
 * Instead, {@code data/sculk_ocean/worldgen/noise_settings/sculk_ocean.json} builds its noise
 * router almost entirely out of <b>references to Mojang's own, already-shipped, already-tested
 * Overworld density functions</b> (e.g. {@code minecraft:overworld/continents},
 * {@code minecraft:overworld/erosion}, {@code minecraft:overworld/depth},
 * {@code minecraft:overworld/sloped_cheese}) - the same technique used by real "reshape the
 * terrain" data packs. This gives stable, well-tested height distribution, working caves,
 * working aquifers, and no risk of the generator producing invalid/NaN densities, for free.
 * <p>
 * The sculk theming is layered on top of that proven terrain shape via two purely data-driven
 * pieces, not Java code:
 * <ul>
 *   <li>a custom {@code surface_rule} that paints the surface with sculk / sculk vein instead
 *       of grass/dirt, and deepslate below (see {@code worldgen/noise_settings/sculk_ocean.json});</li>
 *   <li>a single custom biome ({@code sculk_ocean:sculk_ocean}) with an empty vegetation feature
 *       list (no trees, no grass, no flowers) but with vanilla's own
 *       {@code minecraft:sculk_patch_deep_dark} and {@code minecraft:sculk_vein} placed features
 *       included, so catalysts/shriekers/veins are the real vanilla objects, not re-implemented
 *       ones (see {@code worldgen/biome/sculk_ocean.json}).</li>
 * </ul>
 * This class's only runtime job is to validate that the config's declared expectations
 * ({@code surfaceHeight}, {@code terrainVariation}) are internally consistent and to log a short
 * human-readable summary at startup, so a misconfiguration is visible immediately rather than
 * discovered by exploring the world.
 */
public final class SculkTerrainGenerator {

	/** World height bounds this generator's noise settings target (matches the Overworld). */
	public static final int MIN_Y = -64;
	public static final int MAX_Y = 320;

	private SculkTerrainGenerator() {
	}

	public static void logArchitectureSummary(SculkOceanConfig config, Logger logger) {
		logger.info("[Sculk Ocean] Terrain: reusing vanilla Overworld density functions "
				+ "(continents/erosion/depth/sloped_cheese) for shape, with a custom surface_rule "
				+ "painting sculk/sculk_vein/deepslate. terrainVariation={}, target surfaceHeight={}.",
				config.terrainVariation, config.surfaceHeight);

		if (config.surfaceHeight <= MIN_Y || config.surfaceHeight >= MAX_Y) {
			logger.warn("[Sculk Ocean] surfaceHeight {} is at or beyond the world height bounds "
					+ "[{}, {}] - this was already clamped by SculkOceanConfig#validate, but double "
					+ "check config/sculk_ocean.json.", config.surfaceHeight, MIN_Y, MAX_Y);
		}

		if (!config.terrainVariation) {
			logger.info("[Sculk Ocean] terrainVariation=false is currently informational only: "
					+ "flattening the shipped noise_settings at runtime is not implemented (it would "
					+ "require swapping density functions after datapack load, which this mod does "
					+ "not attempt). See the README's Known Limitations section.");
		}
	}
}
