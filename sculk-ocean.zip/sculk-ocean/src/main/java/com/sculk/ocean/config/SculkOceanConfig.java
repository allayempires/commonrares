package com.sculk.ocean.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParseException;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Runtime configuration for Sculk Ocean, backed by {@code config/sculk_ocean.json}.
 *
 * <p><b>Important scope note (read before changing citySpacing/minCitySpacing/surfaceHeight):</b>
 * Minecraft's world-generation registries (structure sets, noise settings, biomes) are
 * data-driven and are fixed at the moment a world's data pack stack is loaded - they are
 * NOT re-read from this file at runtime. This config file:
 * <ul>
 *   <li>controls purely-runtime behaviour that this mod's own code executes directly
 *       (debug logging verbosity, whether the startup diagnostics run at all), and</li>
 *   <li>is validated and logged at startup so a mismatch between this file and the
 *       shipped datapack (see {@code data/sculk_ocean/worldgen/structure_set/sculk_ancient_cities.json})
 *       is caught early instead of silently ignored.</li>
 * </ul>
 * Changing {@code citySpacing} here does <b>not</b> change already-generated worlds, and it does
 * not even change newly-created worlds unless the structure_set JSON shipped in this jar is
 * edited to match (a data-generation task to keep the two in sync automatically is listed as
 * a "Known limitation - not implemented" in the project README).
 */
public final class SculkOceanConfig {

	private static final String FILE_NAME = "sculk_ocean.json";
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

	// Defaults mirror section 7 of the design spec, and mirror the values baked into
	// data/sculk_ocean/worldgen/structure_set/sculk_ancient_cities.json (spacing=31 chunks
	// / separation=28 chunks, i.e. ~496 / ~448 blocks - see WorldgenMath for the conversion).
	public int citySpacing = 500;
	public int minCitySpacing = 450;
	public int surfaceHeight = 80;
	public boolean terrainVariation = true;
	public boolean allowNormalStructures = false;
	public boolean generateAncientCities = true;
	public boolean seedBasedPlacement = true;
	public boolean debugLogging = false;

	public SculkOceanConfig() {
	}

	/**
	 * Loads the config from disk, creating it with defaults if absent, and validating it.
	 * Never throws: on any failure this logs a clear error and returns safe defaults, per
	 * the "fail safely" requirement - a broken config file must never crash world load.
	 */
	public static SculkOceanConfig load(Logger logger) {
		Path configDir = FabricLoader.getInstance().getConfigDir();
		Path configFile = configDir.resolve(FILE_NAME);

		if (!Files.exists(configFile)) {
			SculkOceanConfig defaults = new SculkOceanConfig();
			defaults.trySave(configFile, logger);
			logger.info("[Sculk Ocean] No config found - wrote defaults to {}", configFile);
			return defaults;
		}

		try (Reader reader = Files.newBufferedReader(configFile, StandardCharsets.UTF_8)) {
			SculkOceanConfig loaded = GSON.fromJson(reader, SculkOceanConfig.class);
			if (loaded == null) {
				logger.warn("[Sculk Ocean] {} was empty or invalid - using defaults.", configFile);
				return new SculkOceanConfig();
			}
			loaded.validate(logger);
			return loaded;
		} catch (IOException | JsonParseException e) {
			logger.error("[Sculk Ocean] Failed to read {} - using defaults. Cause: {}", configFile, e.toString());
			return new SculkOceanConfig();
		}
	}

	/**
	 * Validates and clamps all fields in place. Invalid combinations are corrected to the
	 * nearest safe value and logged, rather than left to silently misbehave or crash later.
	 */
	public void validate(Logger logger) {
		if (citySpacing < 16) {
			logger.warn("[Sculk Ocean] citySpacing {} is too small - clamping to 16.", citySpacing);
			citySpacing = 16;
		}
		if (minCitySpacing < 0) {
			logger.warn("[Sculk Ocean] minCitySpacing {} is negative - clamping to 0.", minCitySpacing);
			minCitySpacing = 0;
		}
		if (minCitySpacing >= citySpacing) {
			int corrected = Math.max(0, citySpacing - 16);
			logger.warn("[Sculk Ocean] minCitySpacing ({}) must be less than citySpacing ({}) - "
					+ "clamping minCitySpacing to {}.", minCitySpacing, citySpacing, corrected);
			minCitySpacing = corrected;
		}
		if (surfaceHeight < -60 || surfaceHeight > 300) {
			int corrected = Math.max(-60, Math.min(300, surfaceHeight));
			logger.warn("[Sculk Ocean] surfaceHeight {} is outside the supported range [-60, 300] - "
					+ "clamping to {}.", surfaceHeight, corrected);
			surfaceHeight = corrected;
		}
	}

	private void trySave(Path configFile, Logger logger) {
		try {
			Files.createDirectories(configFile.getParent());
			try (Writer writer = Files.newBufferedWriter(configFile, StandardCharsets.UTF_8)) {
				GSON.toJson(this, writer);
			}
		} catch (IOException e) {
			logger.error("[Sculk Ocean] Could not write default config to {}: {}", configFile, e.toString());
		}
	}

	@Override
	public String toString() {
		return "SculkOceanConfig{"
				+ "citySpacing=" + citySpacing
				+ ", minCitySpacing=" + minCitySpacing
				+ ", surfaceHeight=" + surfaceHeight
				+ ", terrainVariation=" + terrainVariation
				+ ", allowNormalStructures=" + allowNormalStructures
				+ ", generateAncientCities=" + generateAncientCities
				+ ", seedBasedPlacement=" + seedBasedPlacement
				+ ", debugLogging=" + debugLogging
				+ '}';
	}
}
