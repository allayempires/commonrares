package com.sculk.ocean.worldgen;

import com.sculk.ocean.util.WorldgenMath;

import java.util.ArrayList;
import java.util.List;

/**
 * Diagnostic mirror of the spacing/separation grid used by the real (engine-level) structure
 * placement, for {@code data/sculk_ocean/worldgen/structure_set/sculk_ancient_cities.json}.
 *
 * <p><b>These constants must be kept in sync with that JSON file by hand</b> - there is no
 * automatic link between this Java code and the datapack (see the README's "Known limitations"
 * section). If you change the spacing/separation/salt in the JSON, update the constants below
 * to match, or the startup diagnostics log will describe the wrong grid.
 *
 * <p>The actual placement algorithm used by the game (a {@code minecraft:random_spread}
 * structure placement) partitions the world into a grid of {@code spacing x spacing} chunk
 * cells and places at most one structure per cell, jittered by up to {@code separation} chunks
 * from the cell's edge using an internal, seed-derived RNG. This class independently computes
 * an <em>approximate</em> candidate position per cell (using {@link WorldgenMath}, not the
 * engine's own RNG) purely so the mod can print a human-readable "expect cities roughly here"
 * log during startup diagnostics - it does not read, and cannot desynchronize from, the actual
 * placement the game performs.
 */
public final class AncientCityPlacement {

	/** Target spacing in chunks (~496 blocks). Keep in sync with the structure_set JSON. */
	public static final int SPACING_CHUNKS = 31;

	/** Minimum separation in chunks (~448 blocks). Keep in sync with the structure_set JSON. */
	public static final int SEPARATION_CHUNKS = 28;

	/** Arbitrary but fixed salt. Keep in sync with the structure_set JSON. */
	public static final long SALT = 40_190_814L;

	private AncientCityPlacement() {
	}

	/** A single predicted cell, for logging only. */
	public record CityCandidate(int cellX, int cellZ, int approxBlockX, int approxBlockZ) {
	}

	/**
	 * Predicts the approximate block position of the candidate structure within one
	 * spacing cell. Pure function of (worldSeed, cellX, cellZ): identical inputs always
	 * produce an identical result (see {@link #verifyDeterminism}).
	 */
	public static CityCandidate predictCellCenter(long worldSeed, int cellX, int cellZ) {
		long hash = WorldgenMath.mixSeed(worldSeed, SALT, cellX, cellZ);
		int jitterRange = Math.max(1, SPACING_CHUNKS - SEPARATION_CHUNKS);
		int jitterX = WorldgenMath.boundedJitter(hash, jitterRange);
		int jitterZ = WorldgenMath.boundedJitter(Long.rotateLeft(hash, 32), jitterRange);

		int cellOriginChunkX = cellX * SPACING_CHUNKS;
		int cellOriginChunkZ = cellZ * SPACING_CHUNKS;

		int blockX = WorldgenMath.chunkToBlock(cellOriginChunkX + jitterX) + 8;
		int blockZ = WorldgenMath.chunkToBlock(cellOriginChunkZ + jitterZ) + 8;
		return new CityCandidate(cellX, cellZ, blockX, blockZ);
	}

	/**
	 * Returns candidates for a small, bounded (2r+1)^2 square of cells around the given block
	 * position - bounded deliberately, per the "avoid unbounded collections" requirement.
	 * {@code radiusCells} is clamped to at most 4 (a 9x9 = 81-cell cap).
	 */
	public static List<CityCandidate> nearestCandidates(long worldSeed, int centerBlockX, int centerBlockZ, int radiusCells) {
		int r = Math.max(0, Math.min(radiusCells, 4));
		int centerCellX = Math.floorDiv(WorldgenMath.blockToChunk(centerBlockX), SPACING_CHUNKS);
		int centerCellZ = Math.floorDiv(WorldgenMath.blockToChunk(centerBlockZ), SPACING_CHUNKS);

		List<CityCandidate> results = new ArrayList<>((2 * r + 1) * (2 * r + 1));
		for (int dz = -r; dz <= r; dz++) {
			for (int dx = -r; dx <= r; dx++) {
				results.add(predictCellCenter(worldSeed, centerCellX + dx, centerCellZ + dz));
			}
		}
		return results;
	}

	/**
	 * Self-check used at startup when debug logging is on: confirms that predicting the same
	 * cell twice yields an identical result. Always true by construction (the method is a pure
	 * function), but running it explicitly documents and exercises the determinism guarantee
	 * that section 12 of the design spec asks for, and would catch an accidental future change
	 * (e.g. an unseeded Random) that broke it.
	 */
	public static boolean verifyDeterminism(long worldSeed) {
		CityCandidate first = predictCellCenter(worldSeed, 0, 0);
		CityCandidate second = predictCellCenter(worldSeed, 0, 0);
		return first.equals(second);
	}
}
