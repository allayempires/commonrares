package com.sculk.ocean.util;

/**
 * Small, dependency-free math helpers used by the world-generation diagnostics classes.
 *
 * <p>Nothing here participates in actual chunk generation or structure placement - that is
 * handled entirely by Minecraft's own data-driven, engine-level structure placement system
 * (a {@code minecraft:random_spread} placement, see
 * {@code data/sculk_ocean/worldgen/structure_set/sculk_ancient_cities.json}), which already
 * guarantees deterministic, chunk-boundary-safe, non-duplicating placement - the same proven
 * code path vanilla uses for villages, ancient cities, and every other spread-out structure.
 *
 * <p>This class exists solely so the mod can independently <em>predict</em> and log roughly
 * where a city cell center should be, for startup diagnostics - see {@code AncientCityPlacement}.
 */
public final class WorldgenMath {

	private WorldgenMath() {
	}

	/** Converts a block coordinate to the chunk coordinate that contains it. */
	public static int blockToChunk(int blockCoord) {
		return Math.floorDiv(blockCoord, 16);
	}

	/** Converts a chunk coordinate to the block coordinate of its north-west corner. */
	public static int chunkToBlock(int chunkCoord) {
		return chunkCoord * 16;
	}

	/**
	 * A cheap, well-mixed 64-bit hash combining a world seed, a structure salt, and a cell
	 * coordinate pair. This is a splitmix64-style finalizer, chosen only for good avalanche
	 * behaviour (small input changes flip roughly half the output bits) - it deliberately does
	 * NOT try to reproduce Minecraft's internal structure-placement RNG bit-for-bit, since that
	 * RNG is an internal engine implementation detail. Two calls with identical inputs always
	 * produce an identical output, which is all the diagnostics in AncientCityPlacement need.
	 */
	public static long mixSeed(long worldSeed, long salt, int cellX, int cellZ) {
		long h = worldSeed;
		h ^= salt + 0x9E3779B97F4A7C15L + (h << 6) + (h >>> 2);
		h ^= (long) cellX * 0xBF58476D1CE4E5B9L;
		h ^= (long) cellZ * 0x94D049BB133111EBL;

		// splitmix64 finalizer
		h = (h ^ (h >>> 30)) * 0xBF58476D1CE4E5B9L;
		h = (h ^ (h >>> 27)) * 0x94D049BB133111EBL;
		h = h ^ (h >>> 31);
		return h;
	}

	/** Maps a hash to a non-negative value in {@code [0, bound)}. {@code bound} must be > 0. */
	public static int boundedJitter(long hash, int bound) {
		if (bound <= 0) {
			throw new IllegalArgumentException("bound must be positive, was " + bound);
		}
		long unsigned = hash & Long.MAX_VALUE;
		return (int) (unsigned % bound);
	}
}
