# Sculk Ocean: Ancient City World

A Fabric mod for Minecraft **1.21.1** that adds a new Overworld world type: an endless,
sculk-covered landscape with **surface-adapted Ancient Cities**, spaced roughly every 500
blocks. No commands are needed - select it as the World Type when creating a new world.

---

## 0. Read this first: what was actually verified, and what wasn't

Per the request, here is the honest breakdown (see also §9 "Testing results"):

| Check | Status |
|---|---|
| Project structure, Gradle files, `fabric.mod.json` written | ✅ Done |
| All 16 JSON data-pack files are syntactically valid JSON | ✅ Verified (`python -m json.tool` on every file) |
| All 6 Java files are syntactically valid Java | ✅ Verified (`javac` parses every file with zero syntax errors - see §9) |
| Full `./gradlew build` actually run | ❌ **Not possible in this sandbox** - see below |
| In-game testing (world creation, exploration, save/reload) | ❌ Not performed |

**Why the build couldn't be run here:** this coding environment's network access is restricted
to a fixed allow-list of domains (npm, PyPI, crates.io, GitHub, Ubuntu's package mirrors, a
handful of others). It does **not** include `maven.fabricmc.net`, `libraries.minecraft.net`,
`piston-meta.mojang.com`, or `services.gradle.org`. I tested all four directly and got `403`
from each. Fabric Loom needs those to download Minecraft itself, the Yarn mappings, the Fabric
API, and even the Gradle wrapper distribution - so `./gradlew build` cannot complete here, not
even to the point of a compile error. This is an environment limitation, not a project one: on
a normal development machine with internet access, none of these domains are blocked.

**What I could verify instead, and did:**
1. Every JSON file under `src/main/resources/` parses as valid JSON.
2. I installed a real JDK 21 in this sandbox and ran `javac` directly against all six `.java`
   files (with no classpath, since the Minecraft/Fabric/Gson/SLF4J jars aren't fetchable here).
   Every single reported error is exactly one of: `package ... does not exist` for
   `com.google.gson.*`, `org.slf4j.*`, `net.fabricmc.*`, or `net.minecraft.*` (i.e., "this class
   isn't on the classpath," which is expected), or a direct cascading consequence of that (one
   `@Override ... does not override anything` error, which traces straight back to
   `ModInitializer` itself being unresolvable). **There are zero other errors** - no mismatched
   braces, no typos, no malformed generics, nothing. That's as far as syntax verification can go
   without the actual game/library jars.

**You should run `./gradlew build` yourself** the first time you open this project (see §5) and
treat this README's "Known limitations" (§10) as the specific list of things I flagged as
lower-confidence and worth double-checking against your local 1.21.1 install if anything fails.

---

## 1. Architecture: what was actually built, and why

The spec asks for a "custom terrain generator" and Ancient City "placement manager." Here's
what that means concretely for Fabric 1.21.1, and why:

**Terrain shape is data-driven, not a hand-written `ChunkGenerator`.** Minecraft 1.21.1's
Overworld-style terrain is already a fully data-driven system (noise settings + a graph of
"density functions," in a data pack). Writing a *new* density-function graph from scratch in
Java would mean re-deriving Mojang's terrain math with no way to test it - exactly the kind of
"unsafe hack" the spec warns against, and a real risk of NaN densities, floating terrain, or
world-gen crashes. Instead, `data/sculk_ocean/worldgen/noise_settings/sculk_ocean.json` builds
its terrain shape almost entirely out of **references to Mojang's own, already-shipped Overworld
density functions** (`minecraft:overworld/continents`, `.../erosion`, `.../depth`,
`.../ridges`, `.../final_density`, `.../initial_density_without_jaggedness`). This is a standard,
low-risk technique used by real "reshape the Overworld" data packs (several were found during
research for this project). It gets stable, well-tested height distribution and working caves
for free.
- **Practical effect / known simplification:** because the *shape* is unmodified vanilla
  Overworld shape, the surface has vanilla-like hills, ravines and elevation changes rather than
  a perfectly flat plain. It's "an endless landscape blanketed in sculk," not literally flat. If
  you want it flatter, see §10.
- Only the **surface block palette** (via a custom `surface_rule`: sculk / sculk vein / deepslate
  instead of grass / dirt / stone) and the **biome** (single custom biome, empty vegetation
  feature list, real vanilla `minecraft:sculk_vein` and `minecraft:sculk_patch_deep_dark`
  features for catalysts/shriekers) are custom.

**Ancient City placement uses vanilla's real, proven structure-placement system, not
hand-rolled code.** `data/sculk_ocean/worldgen/structure_set/sculk_ancient_cities.json` is a
`minecraft:random_spread` structure placement (spacing=31 chunks / separation=28 chunks, ≈496 /
≈448 blocks) - the exact mechanism vanilla uses for villages, ancient cities, etc. That engine
code already guarantees, by construction: no duplicate placement on chunk reload, chunk-boundary
safety, and full determinism from the world seed. Reimplementing that in Java would be strictly
worse and riskier. `AncientCityPlacement.java` / `CityPlacementManager.java` do **not** replace
or duplicate this - they independently *predict* roughly where cities should be (pure, seed-based
math) purely to print a bounded, opt-in diagnostic log at server start when `debugLogging: true`.
The authoritative source of truth is always the in-game `/locate structure
sculk_ocean:sculk_ancient_city`.

**Spacing interpretation (per the spec's explicit request to be precise about this):**
`citySpacing` (500, config) / `spacing` (31 chunks, JSON) is the **average target distance**
between city cell centers - not a hard guarantee, because each cell's candidate is jittered
within the cell. `minCitySpacing` (450) / `separation` (28 chunks) **is** a hard guarantee: two
cities can never generate closer than that.

**The actual Ancient City structure is real vanilla content, not a lookalike.**
`data/sculk_ocean/worldgen/structure/sculk_ancient_city.json` is a jigsaw structure that starts
from vanilla's own `minecraft:ancient_city/city_center` building-piece pool - the same NBT
templates the game ships and uses for its own (underground) Ancient Cities. Only the placement
*context* changes: `step: surface_structures`, `terrain_adaptation: beard_thin`, and
`project_start_to_heightmap: WORLD_SURFACE_WG` bring it to the surface and adapt it to uneven
terrain instead of placing it deep underground. A `spawn_overrides` block keeps hostile spawns
inside the city to Warden only, matching vanilla Ancient City behavior.

**Villages / pillager outposts / desert pyramids / mineshafts / ruined portals / shipwrecks /
strongholds / vanilla's own (underground) Ancient City are all disabled**, defense-in-depth,
two ways at once: (a) the custom biome simply isn't a member of any vanilla structure's
`#minecraft:has_structure/...` biome tag, so nothing "belongs" there by default; and (b) this mod
also ships same-path overrides for those structures' `structure_set` files
(`data/minecraft/worldgen/structure_set/villages.json`, etc.) with an empty structure list, so
even if (a) were somehow wrong, nothing from them can ever be selected. No mixins, no Java hacks.

**The Overworld's generator is replaced; the Nether and the End are untouched.** This mod ships
a `world_preset` (`data/sculk_ocean/worldgen/world_preset/sculk_ocean.json`) that swaps only the
`minecraft:overworld` dimension's generator; `minecraft:the_nether` and `minecraft:the_end` are
plain string references to the normal vanilla dimensions. Portals work exactly as in any other
world - nothing about Nether/End access is changed. This was chosen over a wholly separate custom
dimension specifically because a separate dimension would need its own portal-creation and
teleport logic (more moving parts, more risk, and arguably a worse fit for "hardcore survival
world type" than something selectable from the normal Create World screen).

---

## 2. Project structure

```
sculk-ocean/
  build.gradle, settings.gradle, gradle.properties   Fabric Loom project files
  src/main/java/com/sculk/ocean/
    SculkOceanMod.java              ModInitializer: loads config, logs a startup summary,
                                     registers the diagnostics hook. That's all Java does here -
                                     see §1 for why world gen itself is data, not code.
    config/SculkOceanConfig.java    config/sculk_ocean.json load/validate/save (Gson), fails
                                     safe on any I/O or parse error.
    worldgen/SculkTerrainGenerator.java   Logs which architecture is in effect + validates
                                     surfaceHeight/terrainVariation are internally consistent.
    worldgen/AncientCityPlacement.java    Pure, deterministic math predicting approximate city
                                     cell centers, for diagnostics only (see §1).
    worldgen/CityPlacementManager.java    Runs one bounded (<=81 entries), opt-in diagnostic
                                     log at server start - no per-chunk/per-tick hooks.
    util/WorldgenMath.java          Shared seed-hashing / chunk<->block math.
  src/main/resources/
    fabric.mod.json
    data/sculk_ocean/worldgen/
      biome/sculk_ocean.json            The one biome used everywhere: no vegetation, real
                                         vanilla sculk features, ore features, hostile spawns.
      noise_settings/sculk_ocean.json   Terrain shape (vanilla density-function references) +
                                         sculk surface_rule. See §1.
      structure/sculk_ancient_city.json Jigsaw structure reusing vanilla's Ancient City pool.
      structure_set/sculk_ancient_cities.json   Spacing/separation/salt for city placement.
      world_preset/sculk_ocean.json     The selectable "World Type."
    data/minecraft/
      tags/worldgen/world_preset/normal.json    Adds our preset to the normal (non-experimental)
                                                 World Type list.
      worldgen/structure_set/{villages,pillager_outposts,desert_pyramids,mineshafts,
        ruined_portals,shipwrecks,strongholds,ancient_cities}.json
                                                 Empty-list overrides - see §1.
    assets/sculk_ocean/lang/en_us.json  Biome / world-preset display names.
```

No mixins, no client-only code, no classes that don't do anything (per the "don't create empty
classes just to match a folder layout" instruction, the originally-suggested
`CityPlacementManager` / `AncientCityPlacement` / `SculkTerrainGenerator` split was kept, but
`SculkWorldPreset.java` was **not** created as a Java class, because the world preset is pure
data - see `world_preset/sculk_ocean.json` - and a Java class that just re-described that JSON
would be an empty wrapper).

---

## 3. Config

`config/sculk_ocean.json` (created with these defaults on first run if missing):

```json
{
  "citySpacing": 500,
  "minCitySpacing": 450,
  "surfaceHeight": 80,
  "terrainVariation": true,
  "allowNormalStructures": false,
  "generateAncientCities": true,
  "seedBasedPlacement": true,
  "debugLogging": false
}
```

**Important scope note:** Minecraft's world-generation registries are fixed at world-data-pack
load time; this file is *not* re-read by the engine's generator itself. Concretely:
- `citySpacing` / `minCitySpacing` are validated and logged at startup, and documented as the
  source of truth, but changing them here does **not** change the spacing of an existing or even
  a newly-created world by itself - you'd also need to edit
  `structure_set/sculk_ancient_cities.json`'s `spacing`/`separation` (in chunks: blocks ÷ 16) to
  match, then create a new world. Keeping `AncientCityPlacement.java`'s constants, the JSON, and
  this config file in sync is currently a manual step (see §10).
- `generateAncientCities: false` is honored at runtime (skips the diagnostics), but does not
  itself remove the structure from a world already created with it enabled - again, edit the
  datapack and start a new world.
- `allowNormalStructures`, `debugLogging`, `seedBasedPlacement` are logged/validated; only
  `debugLogging` currently changes real runtime behavior (enables the startup diagnostic log).
- Invalid values (negative spacing, `minCitySpacing >= citySpacing`, out-of-range
  `surfaceHeight`) are clamped to a safe value and logged, never left to crash world load.

---

## 4. Hardcore / survival compatibility

- No command is required at any point - the world type is chosen from the normal Create World
  screen.
- The mod grants no items, no abilities, and disables no survival mechanics.
- Normal ore generation (coal/iron/copper/gold/redstone/diamond/lapis/emerald, plus stone-type
  patches) is included in the biome so mining/progression works.
- Water and lava springs are included for early-game water/lava access (buckets, portals,
  farming).
- Hostile mobs (zombie/skeleton/spider/creeper/enderman) spawn on the surface; inside an Ancient
  City, spawns are restricted to Warden only, matching vanilla behavior.
- All Java code is common/server-safe (`environment: "*"` in `fabric.mod.json`, no client-only
  imports anywhere) - this mod works in singleplayer and on a dedicated server.

---

## 5. Build instructions (run these yourself - see §0 for why I couldn't)

Requirements: JDK 21, internet access to `maven.fabricmc.net` / Mojang's libraries / Fabric's
Maven (all blocked *only* in this sandbox, not on a normal machine).

```bash
cd sculk-ocean
./gradlew build
```

First run downloads Minecraft, Yarn mappings, and Fabric API via Loom - this can take several
minutes. On success, the mod jar is at:

```
build/libs/sculk-ocean-1.0.0.jar
```

(`build/libs/sculk-ocean-1.0.0-sources.jar` is also produced, from `withSourcesJar()`.)

If it doesn't build cleanly the first time, see §10 for the specific fields I flagged as
worth double-checking (I could not run this build myself to confirm them).

---

## 6. Installation instructions

1. Install [Fabric Loader](https://fabricmc.net/use/) for Minecraft 1.21.1 (client or server).
2. Install [Fabric API](https://modrinth.com/mod/fabric-api) for 1.21.1 into the same
   `mods` folder.
3. Copy `sculk-ocean-1.0.0.jar` into that `mods` folder.
4. Launch the game (or start the server).

---

## 7. Creating a new world with the mod

1. **Singleplayer:** Create New World -> click the **World Type** button (it cycles through
   installed types) until it reads **"Sculk Ocean: Ancient City World,"** or open "Customize"
   if your launcher shows a picker list instead of a cycle button -> Create.
2. **Dedicated server:** in `server.properties`, set `level-type=sculk_ocean:sculk_ocean`
   before first launch (this only takes effect on a brand-new world folder).
3. Existing worlds are unaffected either way - this only applies to newly created worlds.

---

## 8. Performance notes

- No per-tick or per-chunk-load code runs at all in normal play; the only mod code that runs
  after startup is standard Gson config I/O (once, at load) - there is nothing here that can
  slow down exploration.
- The one diagnostic log at server start is a fixed, bounded computation (at most an 9x9=81-cell
  loop of simple arithmetic), gated behind `debugLogging: false` by default.
- No unbounded collections anywhere (`nearestCandidates` is hard-capped at a radius of 4 cells).
- Structure and terrain generation performance is whatever vanilla's own `minecraft:noise`
  chunk generator and `minecraft:random_spread` structure placement already deliver, since both
  are used unmodified - no custom generation-time code runs per chunk.

---

## 9. Testing results

- ✅ **JSON validity:** all 16 data-pack JSON files parse successfully (`python3 -m json.tool`
  run against every file in this sandbox).
- ✅ **Java syntax:** all 6 `.java` files parse with `javac` (JDK 21) with zero syntax errors;
  every reported diagnostic is an expected "missing classpath" error for a Minecraft/Fabric/
  Gson/SLF4J type that isn't fetchable in this sandbox (see §0 for the exact grep output).
- ❌ **Full Gradle build:** not run - `maven.fabricmc.net`, `libraries.minecraft.net`,
  `piston-meta.mojang.com`, and `services.gradle.org` all returned `403` when tested directly
  from this sandbox.
- ❌ **In-game testing** (new world generation, exploring several thousand blocks, multiple
  cities, save/reload, dedicated server, multiplayer): not performed, for the same reason.

---

## 10. Known limitations / things to double-check against your local install

I verified everything I could without a live Minecraft/Fabric environment, but a few IDs and
schema details couldn't be checked against the actual shipped game data from this sandbox.
If `./gradlew build` or world creation fails, check these first:

1. **`minecraft:ancient_city/city_center` / `minecraft:city_anchor`** (in
   `structure/sculk_ancient_city.json`) - the vanilla Ancient City's starting template pool and
   jigsaw name. I'm reasonably confident in these (corroborated by a third-party mod's public
   source using the same IDs), but couldn't verify against the game jar directly. If the
   structure generates as an empty/tiny footprint, extract
   `data/minecraft/worldgen/template_pool/ancient_city/` from your client/server jar (or run
   `./gradlew genSources`) and compare.
2. **`ancient_cities.json`** - I used this as the filename for overriding vanilla's own
   (underground) Ancient City structure_set; if your installed version actually uses
   `ancient_city.json` (singular), the override won't take effect and vanilla's underground
   Ancient Cities will *also* generate alongside the surface ones. Not a crash - just extra
   underground content. Fix by renaming the file to match your local
   `data/minecraft/worldgen/structure_set/` listing.
3. **Ore/spring placed-feature IDs** in `biome/sculk_ocean.json` (`minecraft:ore_iron_upper`,
   etc.) - these are the standard vanilla names, but weren't individually checked against the
   1.21.1 registry from this sandbox.
4. **`minecraft:ambient.deep_dark.loop`** ambient sound ID - if this doesn't exist, it should
   fail soft (silently missing sound) rather than break generation, but hasn't been confirmed.
5. **Loom / Yarn / Fabric Loader / Fabric API exact versions** in `gradle.properties` - pinned to
   versions that were current for 1.21.1 as of my knowledge; check
   [fabricmc.net/develop](https://fabricmc.net/develop) for newer patch releases before building.
6. **Config-to-datapack sync is manual** (see §3) - there's no build step that generates
   `structure_set/sculk_ancient_cities.json` from `config/sculk_ocean.json` automatically. A
   `datagen` source set reading `SculkOceanConfig` and emitting that JSON would close this gap
   cleanly, but wasn't implemented.
7. **Terrain is vanilla-shaped, not flattened** (see §1) - hills/ravines exist; it isn't a
   perfectly flat plain. To flatten it, the lowest-risk change is scaling down the `erosion`/
   `continents` density function outputs (e.g. wrap them in `"minecraft:mul"` by ~0.3-0.5)
   before they reach `final_density` - happy to do this as a follow-up if you want it flatter.
8. **`allowNormalStructures: true`** currently has no effect on the shipped datapack (see §3) -
   it's read, validated, and logged, but doesn't regenerate the override files.

None of the above are guesses made carelessly - each is my best-verified answer given what I
could check in this sandbox (public documentation, JSON syntax validation, Java syntax
validation), flagged honestly rather than asserted as certain.
