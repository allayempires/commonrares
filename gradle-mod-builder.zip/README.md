# Gradle Mod Builder

A small local web app that accepts a Gradle project ZIP, runs `build`, and exposes generated JAR files for download.

## Requirements

- Node.js 18+
- Gradle installed and available as `gradle`, OR a project-local `gradlew`
- Java/JDK required by the mod/plugin project

## Run

```bash
npm install
npm start
```

Open:

```text
http://localhost:8080
```

For a Fabric/Forge/NeoForge project, the ZIP should contain `gradlew` and/or `build.gradle` / `build.gradle.kts`.

## Important security warning

This service executes uploaded Gradle projects. Keep it local or behind strong authentication and isolation. Do not expose it publicly as-is.
