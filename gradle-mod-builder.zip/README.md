# Gradle Mod Builder

A small local web app that accepts a Gradle project ZIP, runs `build`, and exposes generated JAR files for download.

## Requirements

- Node.js 18+
- Gradle installed and available as `gradle`, OR a project-local `gradlew`
- Java/JDK required by the mod/plugin project

## Run

```bash
npm install
npm start
```

Open:

```text
http://localhost:8080
```

For a Fabric/Forge/NeoForge project, the ZIP should contain `gradlew` and/or `build.gradle` / `build.gradle.kts`.

## Important security warning

This service executes uploaded Gradle projects. Keep it local or behind strong authentication and isolation. Do not expose it publicly as-is.


## Codespaces troubleshooting

Run the backend inside the Codespace:

```bash
npm install
npm start
```

Then open the **Forwarded Port** for port `8080`. Do not open `index.html` from GitHub, GitHub Pages, or the repository preview, because that page has no Node.js backend behind `/api/build`.

Test the backend first:

```bash
curl http://localhost:8080/api/health
```

Expected response:

```json
{"ok":true,"service":"gradle-mod-builder"}
```
