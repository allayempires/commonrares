const express = require("express");
const multer = require("multer");
const AdmZip = require("adm-zip");
const fs = require("fs");
const fsp = fs.promises;
const path = require("path");
const crypto = require("crypto");
const { spawn } = require("child_process");

const app = express();
const PORT = Number(process.env.PORT || 8080);
const ROOT = __dirname;
const JOBS = path.join(ROOT, "jobs");
const PUBLIC = path.join(ROOT, "public");
const MAX_UPLOAD = 250 * 1024 * 1024; // 250 MB
const BUILD_TIMEOUT_MS = 10 * 60 * 1000; // 10 minutes

fs.mkdirSync(JOBS, { recursive: true });

app.use(express.json());
app.use(express.static(PUBLIC));

const upload = multer({
  dest: path.join(ROOT, "incoming"),
  limits: { fileSize: MAX_UPLOAD },
  fileFilter: (req, file, cb) => {
    const ok = path.extname(file.originalname).toLowerCase() === ".zip";
    cb(ok ? null : new Error("Only .zip files are accepted"), ok);
  }
});

function safeId() {
  return crypto.randomBytes(12).toString("hex");
}

function safeResolve(base, candidate) {
  const resolvedBase = path.resolve(base) + path.sep;
  const resolved = path.resolve(base, candidate);
  if (!resolved.startsWith(resolvedBase)) {
    throw new Error("Unsafe ZIP path detected");
  }
  return resolved;
}

async function extractZipSafely(zipPath, destination) {
  const zip = new AdmZip(zipPath);
  const entries = zip.getEntries();

  for (const entry of entries) {
    const entryName = entry.entryName.replaceAll("\\", "/");
    if (!entryName || entryName.startsWith("/") || entryName.includes("\0")) {
      throw new Error("Invalid ZIP entry");
    }
    const outputPath = safeResolve(destination, entryName);
    if (entry.isDirectory) {
      await fsp.mkdir(outputPath, { recursive: true });
      continue;
    }
    await fsp.mkdir(path.dirname(outputPath), { recursive: true });
    await fsp.writeFile(outputPath, entry.getData());
  }
}

async function findProjectRoot(jobDir) {
  const entries = await fsp.readdir(jobDir, { withFileTypes: true });
  const hasGradle = entries.some(e => e.isFile() && ["gradlew", "gradlew.bat", "build.gradle", "build.gradle.kts", "settings.gradle", "settings.gradle.kts"].includes(e.name));
  if (hasGradle) return jobDir;

  const dirs = entries.filter(e => e.isDirectory());
  if (dirs.length === 1) {
    const nested = path.join(jobDir, dirs[0].name);
    const nestedEntries = await fsp.readdir(nested);
    if (nestedEntries.some(name => ["gradlew", "build.gradle", "build.gradle.kts", "settings.gradle", "settings.gradle.kts"].includes(name))) {
      return nested;
    }
  }
  throw new Error("Gradle project files were not found in the ZIP root or its single top-level folder");
}

async function runCommand(command, args, cwd, onData) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { cwd, env: { ...process.env, CI: "true" } });
    let settled = false;
    const timer = setTimeout(() => {
      if (!settled) {
        child.kill("SIGKILL");
        reject(new Error("Build timed out after 10 minutes"));
      }
    }, BUILD_TIMEOUT_MS);

    child.stdout.on("data", d => onData(d.toString()));
    child.stderr.on("data", d => onData(d.toString()));
    child.on("error", err => {
      clearTimeout(timer);
      if (!settled) { settled = true; reject(err); }
    });
    child.on("close", code => {
      clearTimeout(timer);
      if (!settled) {
        settled = true;
        resolve(code ?? 1);
      }
    });
  });
}

async function findJars(projectRoot) {
  const result = [];
  async function walk(dir) {
    const entries = await fsp.readdir(dir, { withFileTypes: true });
    for (const e of entries) {
      const full = path.join(dir, e.name);
      if (e.isDirectory()) {
        if (![".gradle", ".git", "node_modules"].includes(e.name)) await walk(full);
      } else if (e.isFile() && full.includes(`${path.sep}build${path.sep}libs${path.sep}`) && e.name.endsWith(".jar")) {
        result.push(full);
      }
    }
  }
  await walk(projectRoot);
  return result;
}

app.post("/api/build", upload.single("project"), async (req, res) => {
  let jobDir;
  try {
    if (!req.file) return res.status(400).json({ error: "Please upload a ZIP file" });

    const jobId = safeId();
    jobDir = path.join(JOBS, jobId);
    const projectDir = path.join(jobDir, "project");
    await fsp.mkdir(projectDir, { recursive: true });

    await extractZipSafely(req.file.path, projectDir);
    await fsp.unlink(req.file.path).catch(() => {});

    const projectRoot = await findProjectRoot(projectDir);
    let gradleCommand;
    let gradleArgs;

    if (fs.existsSync(path.join(projectRoot, "gradlew"))) {
      await fsp.chmod(path.join(projectRoot, "gradlew"), 0o755);
      gradleCommand = path.join(projectRoot, "gradlew");
      gradleArgs = ["build", "--no-daemon", "--stacktrace"];
    } else {
      gradleCommand = "gradle";
      gradleArgs = ["build", "--no-daemon", "--stacktrace"];
    }

    let log = "";
    const append = chunk => {
      log += chunk;
      if (log.length > 250000) log = log.slice(-250000);
    };

    const exitCode = await runCommand(gradleCommand, gradleArgs, projectRoot, append);
    const jars = exitCode === 0 ? await findJars(projectRoot) : [];

    const artifacts = [];
    for (const jar of jars) {
      const artifactName = `${jobId}-${path.basename(jar)}`;
      const artifactPath = path.join(jobDir, artifactName);
      await fsp.copyFile(jar, artifactPath);
      artifacts.push({ name: path.basename(jar), url: `/api/download/${jobId}/${encodeURIComponent(artifactName)}` });
    }

    res.json({
      ok: exitCode === 0,
      exitCode,
      log,
      artifacts,
      note: exitCode === 0 ? "Build completed" : "Build failed; inspect the log"
    });
  } catch (err) {
    if (req.file?.path) await fsp.unlink(req.file.path).catch(() => {});
    res.status(400).json({ error: err.message });
  }
});

app.get("/api/download/:jobId/:file", async (req, res) => {
  try {
    const jobId = req.params.jobId;
    const file = decodeURIComponent(req.params.file);
    const jobDir = path.join(JOBS, jobId);
    const filePath = safeResolve(jobDir, file);
    if (!fs.existsSync(filePath)) return res.status(404).send("Artifact not found");
    res.download(filePath, path.basename(filePath));
  } catch {
    res.status(400).send("Invalid file path");
  }
});

app.get("/api/health", (req, res) => {
  res.json({ ok: true, service: "gradle-mod-builder" });
});

app.use((req, res, next) => {
  if (req.path.startsWith("/api/")) {
    return res.status(404).json({ error: `API route not found: ${req.method} ${req.path}` });
  }
  next();
});

app.use((err, req, res, next) => {
  console.error(err);
  if (res.headersSent) return next(err);
  if (req.path.startsWith("/api/")) {
    return res.status(err.status || 400).json({ error: err.message || "API request failed" });
  }
  res.status(err.status || 500).send("Server error");
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Gradle Mod Builder running at http://0.0.0.0:${PORT}`);
});