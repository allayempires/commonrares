const form = document.querySelector("#buildForm");
const input = document.querySelector("#project");
const fileName = document.querySelector("#fileName");
const buildBtn = document.querySelector("#buildBtn");
const log = document.querySelector("#log");
const status = document.querySelector("#status");
const artifacts = document.querySelector("#artifacts");

input.addEventListener("change", () => {
  fileName.textContent = input.files[0]?.name || "Choose project ZIP";
});

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  if (!input.files[0]) return;

  buildBtn.disabled = true;
  status.textContent = "Building…";
  artifacts.innerHTML = "";
  log.textContent = "Uploading ZIP and starting Gradle…\n";

  const data = new FormData();
  data.append("project", input.files[0]);

  try {
    const response = await fetch("/api/build", { method: "POST", body: data });
    const contentType = response.headers.get("content-type") || "";
    const raw = await response.text();
    let result;

    try {
      result = contentType.includes("application/json") ? JSON.parse(raw) : null;
    } catch {
      result = null;
    }

    if (!result) {
      const hint = response.status === 404
        ? "Backend route not found. Open the Codespaces forwarded port URL, not the GitHub repository page, and make sure npm start is running."
        : `Server returned ${response.status} ${response.statusText} instead of JSON. Make sure the Node.js backend is running on the same origin.`;
      throw new Error(hint);
    }

    if (!response.ok) throw new Error(result.error || "Request failed");

    log.textContent = result.log || "No build output received.";
    status.textContent = result.ok ? "Success" : `Failed (${result.exitCode})`;

    if (result.artifacts?.length) {
      for (const artifact of result.artifacts) {
        const row = document.createElement("div");
        row.className = "artifact";
        row.innerHTML = `<span>${escapeHtml(artifact.name)}</span><a href="${artifact.url}">Download JAR</a>`;
        artifacts.appendChild(row);
      }
    } else if (result.ok) {
      artifacts.textContent = "Build succeeded, but no JAR was found in build/libs.";
    }
  } catch (error) {
    status.textContent = "Error";
    log.textContent = error.message;
  } finally {
    buildBtn.disabled = false;
  }
});

function escapeHtml(value) {
  return value.replace(/[&<>"']/g, c => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[c]));
}